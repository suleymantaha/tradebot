import json
from typing import Any, Optional

from app.core.rate_limit import get_redis

# Spot symbols cache keys
SPOT_SYMBOLS_CACHE_KEY = "symbols:spot:list"
SPOT_SYMBOLS_CACHE_LAST_GOOD_KEY = "symbols:spot:last_good"
SPOT_SYMBOLS_CACHE_HIT_KEY = "symbols:spot:hits"
SPOT_SYMBOLS_CACHE_MISS_KEY = "symbols:spot:misses"
SPOT_SYMBOLS_CACHE_LAST_REFRESH_TS_KEY = "symbols:spot:last_refresh_ts"

# Futures symbols cache keys
FUTURES_SYMBOLS_CACHE_KEY = "symbols:futures:list"
FUTURES_SYMBOLS_CACHE_LAST_GOOD_KEY = "symbols:futures:last_good"
FUTURES_SYMBOLS_CACHE_HIT_KEY = "symbols:futures:hits"
FUTURES_SYMBOLS_CACHE_MISS_KEY = "symbols:futures:misses"
FUTURES_SYMBOLS_CACHE_LAST_REFRESH_TS_KEY = "symbols:futures:last_refresh_ts"


async def read_json(key: str) -> Optional[Any]:
    """Read a JSON value from Redis, returning None if missing."""
    r = await get_redis()
    raw = await r.get(key)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except Exception:
        # If value is not valid JSON, return as-is
        return raw


async def write_json(key: str, value: Any, ttl_seconds: Optional[int] = None) -> bool:
    """Write a JSON-serialized value to Redis with optional TTL."""
    r = await get_redis()
    payload = json.dumps(value)
    if ttl_seconds and ttl_seconds > 0:
        await r.set(key, payload, ex=ttl_seconds)
    else:
        await r.set(key, payload)
    return True


async def incr(key: str) -> int:
    """Increment a Redis counter and return the new value."""
    r = await get_redis()
    return await r.incr(key)

