import os
import time
import logging
from typing import List
import asyncio

from app.core.binance_client import BinanceClientWrapper
from app.core.redis_client import (
    write_json,
    FUTURES_SYMBOLS_CACHE_KEY,
    FUTURES_SYMBOLS_CACHE_LAST_GOOD_KEY,
    FUTURES_SYMBOLS_CACHE_LAST_REFRESH_TS_KEY,
)
from app.core.celery_app import celery_app

logger = logging.getLogger(__name__)


def _build_futures_symbols_payload() -> List[dict]:
    symbols = BinanceClientWrapper.get_public_futures_symbols()
    usdt_symbols = [s for s in symbols if s.get('quoteAsset') == 'USDT']
    priority_symbols = ['BTC', 'ETH', 'BNB', 'SOL', 'ADA', 'AVAX', 'DOT', 'MATIC']
    prioritized_symbols: List[dict] = []
    other_symbols: List[dict] = []
    for symbol in usdt_symbols:
        if symbol.get('baseAsset') in priority_symbols:
            prioritized_symbols.append(symbol)
        else:
            other_symbols.append(symbol)
    prioritized_symbols.sort(key=lambda x: priority_symbols.index(x['baseAsset']) if x['baseAsset'] in priority_symbols else 999)
    other_symbols.sort(key=lambda x: x['symbol'])
    final_symbols = prioritized_symbols + other_symbols
    return final_symbols


async def warmup_futures_symbols_cache_once():
    """Warm-up futures cache at startup without blocking the server."""
    ttl_seconds = int(os.getenv("FUTURES_SYMBOLS_CACHE_TTL_SECONDS", "600"))
    try:
        final_symbols = await asyncio.to_thread(_build_futures_symbols_payload)
        wrote = await write_json(FUTURES_SYMBOLS_CACHE_KEY, final_symbols, ttl_seconds=ttl_seconds)
        if wrote:
            await write_json(FUTURES_SYMBOLS_CACHE_LAST_GOOD_KEY, final_symbols)
            await write_json(FUTURES_SYMBOLS_CACHE_LAST_REFRESH_TS_KEY, int(time.time()))
            logger.info(f"Startup warm-up: futures cache WRITE {len(final_symbols)} items, TTL={ttl_seconds}s")
    except Exception as e:
        logger.warning(f"Startup warm-up for futures cache failed: {e}")


@celery_app.task(name='app.core.cache_warmup_tasks.refresh_futures_symbols_cache')
def refresh_futures_symbols_cache():
    """Celery task: periodically refresh futures symbols cache."""
    ttl_seconds = int(os.getenv("FUTURES_SYMBOLS_CACHE_TTL_SECONDS", "600"))
    try:
        final_symbols = _build_futures_symbols_payload()
        # Redis helpers are async; for Celery task, run via asyncio loop
        async def _write():
            wrote = await write_json(FUTURES_SYMBOLS_CACHE_KEY, final_symbols, ttl_seconds=ttl_seconds)
            if wrote:
                await write_json(FUTURES_SYMBOLS_CACHE_LAST_GOOD_KEY, final_symbols)
                await write_json(FUTURES_SYMBOLS_CACHE_LAST_REFRESH_TS_KEY, int(time.time()))
        asyncio.run(_write())
        logger.info(f"Celery warm-up: futures cache WRITE {len(final_symbols)} items, TTL={ttl_seconds}s")
    except Exception as e:
        logger.error(f"Celery warm-up for futures cache failed: {e}")


@celery_app.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    """Register periodic refresh every 5 minutes without editing celery_app.py."""
    sender.add_periodic_task(300.0, refresh_futures_symbols_cache.s(), name='refresh-futures-symbols-every-5-min')
    # Trigger an immediate warm-up at worker startup (best-effort)
    try:
        refresh_futures_symbols_cache.delay()
    except Exception:
        pass
